
from datetime import datetime
from weddingapp import db 


class Guests(db.Model):
    #columname=db.Column(db.datatype())
    guest_id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    guest_fname =db.Column(db.String(50), nullable=False)
    guest_lname =db.Column(db.String(50), nullable=False)
    guest_email=db.Column(db.String(50), nullable=False)
    guest_pwd =db.Column(db.String(30), nullable=False)
    guest_regdate=db.Column(db.DateTime(), default=datetime.utcnow())
class Gifts(db.Model):
    #columname=db.Column(db.datatype())
    gift_id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    gift_name =db.Column(db.String(50), nullable=False)
    gift_image =db.Column(db.String(50), nullable=False)
    giftsubmitted_on=db.Column(db.DateTime(), default=datetime.utcnow())

class Admin(db.Model):
    #columname=db.Column(db.datatype())
    admin_id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    admin_username =db.Column(db.String(50), nullable=False)
    admin_pwd =db.Column(db.String(30), nullable=False)
class Uniform(db.Model):
    #columname=db.Column(db.datatype())
    uni_id = db.Column(db.Integer(), primary_key=True, autoincrement=True)
    uni_name =db.Column(db.String(50), nullable=False)
    uni_price =db.Column(db.Float(), nullable=False)
    
